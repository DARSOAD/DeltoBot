from telegram import CallbackQuery
from telegram.ext import ContextTypes
from database.mongo import increment_counter

async def counter_button(update: CallbackQuery, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    # user_id = update.effective_user.id
    # increment_counter(user_id)  # Incrementa el contador en la base de datos

    # Respondemos al usuario
    await query.edit_message_text(text="¡Empezamos a contar! Cada vez que interactúes, el contador aumentará.")
