from telegram import CallbackQuery
from telegram.ext import ContextTypes
from services.openai_api import analyze_sentiment

async def analyze_sentiment_button(update: CallbackQuery, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    # Aquí debes tener el texto que analizar (puedes obtenerlo de la conversación)
    text_to_analyze = "Texto de ejemplo para analizar"
    sentiment = analyze_sentiment(text_to_analyze)

    # Enviar la respuesta al usuario
    await query.edit_message_text(text=f"El sentimiento es: {sentiment}")
