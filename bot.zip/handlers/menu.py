from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes

async def start(update, context: ContextTypes.DEFAULT_TYPE):
    keyboard = [
        [InlineKeyboardButton("¡Quiero saber el clima!", callback_data='weather')],
        [InlineKeyboardButton("¡Quiero contar!", callback_data='counter')],
    ]
    reply_markup = InlineKeyboardMarkup(keyboard)
    await update.message.reply_text('Bienvenido al Bot de clima más cool del continente. ¿Qué te gustaría hacer?', reply_markup=reply_markup)
