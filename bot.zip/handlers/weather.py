from telegram import CallbackQuery
from telegram.ext import ContextTypes
# from services.weather_api import get_weather

async def weather_button(update: CallbackQuery, context: ContextTypes.DEFAULT_TYPE):
    query = update.callback_query
    await query.answer()

    # city = "Bogotá"  # Ejemplo de ciudad, esto debe ser dinámico
    # weather = get_weather(city)

    # # Aquí generamos la respuesta con la información del clima
    # await query.edit_message_text(text=f"El clima en {city} es: {weather['weather'][0]['description']}.\n"
    #                                   f"Temperatura: {weather['main']['temp']}°C.")
    await query.edit_message_text(text="¡Dime en qué ciudad te encuentras y te dare los detalles del clima de hoy!")