from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackQueryHandler
from handlers.menu import start
from handlers.weather import weather_button
from handlers.counter import counter_button
from dotenv import load_dotenv
import os

load_dotenv()

TELEGRAM_TOKEN = os.getenv("TELEGRAM_TOKEN")

def main():
    # Inicialización el bot
    app = ApplicationBuilder().token(TELEGRAM_TOKEN).build()

    # Handlers
    app.add_handler(CommandHandler("start", start))
    app.add_handler(CallbackQueryHandler(weather_button, pattern='weather'))
    app.add_handler(CallbackQueryHandler(counter_button, pattern='counter'))

    # Bot con polling
    app.run_polling()

if __name__ == '__main__':
    main()
