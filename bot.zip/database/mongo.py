from pymongo import MongoClient

def get_db():
    client = MongoClient("mongodb://localhost:27017/")
    return client["delto_bot_db"]

def increment_counter(user_id):
    db = get_db()
    counters = db.counters
    counters.update_one({"user_id": user_id}, {"$inc": {"counter": 1}}, upsert=True)
