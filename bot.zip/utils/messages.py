# Mensajes comunes que puedes utilizar
WELCOME_MESSAGE = "Bienvenido a DeltoBot. ¿Qué te gustaría hacer?"
CLIMATE_MESSAGE = "¡Claro! Por favor, indícame la ciudad para conocer el clima."
COUNTER_MESSAGE = "¡Empezamos a contar! Cada vez que interactúes, el contador aumentará."
