from openai import OpenAI

client = OpenAI(
  api_key="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"
)

completion = client.chat.completions.create(
  model="gpt-4o-mini",
  store=True,
  messages=[
    {"role": "user", "content": "write a haiku about ai"}
  ]
)

print(completion.choices[0].message);
